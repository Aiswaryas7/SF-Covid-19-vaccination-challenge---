<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>test3</label>
    <protected>false</protected>
    <values>
        <field>Latitude__c</field>
        <value xsi:type="xsd:double">53.28603418885669</value>
    </values>
    <values>
        <field>Location__c</field>
        <value xsi:type="xsd:string">Citywest Convention Centre Dublin</value>
    </values>
    <values>
        <field>Longitude__c</field>
        <value xsi:type="xsd:double">-6.444447772580229</value>
    </values>
</CustomMetadata>
