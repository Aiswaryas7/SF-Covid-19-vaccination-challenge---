<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>test1</label>
    <protected>false</protected>
    <values>
        <field>Latitude__c</field>
        <value xsi:type="xsd:double">53.298810877564875</value>
    </values>
    <values>
        <field>Location__c</field>
        <value xsi:type="xsd:string">Galway Racecourse</value>
    </values>
    <values>
        <field>Longitude__c</field>
        <value xsi:type="xsd:double">-8.997003657335881</value>
    </values>
</CustomMetadata>
