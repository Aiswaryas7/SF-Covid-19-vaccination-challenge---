<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>test2</label>
    <protected>false</protected>
    <values>
        <field>Latitude__c</field>
        <value xsi:type="xsd:double">51.89742637092438</value>
    </values>
    <values>
        <field>Location__c</field>
        <value xsi:type="xsd:string">City Hall Cork</value>
    </values>
    <values>
        <field>Longitude__c</field>
        <value xsi:type="xsd:double">-8.465763459121026</value>
    </values>
</CustomMetadata>
